@extends('layouts.master.main')
@section('index-content')

<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header with-border">
              <img src="/AdminLTE/dist/img/ikitas.jpg" width="100%;" height="100%;">
            </div>
        </div>
    </div>
</div> 


@stop
