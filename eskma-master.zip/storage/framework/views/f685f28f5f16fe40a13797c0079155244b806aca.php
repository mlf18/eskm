<?php $__env->startSection('content'); ?>


<section class="content">
      <!-- Info boxes -->
      <div class="row">
        <div class="">
          <div class="info-box">
      <div class="box-body">
              

    <?php echo Form::open(['url'=>'berita/store','class'=>'form-horizontal']); ?>

    <div class="form-gorup">
      <?php echo Form::label('judul', 'Judul Berita', ['class'=>'control-label col-md-2']); ?>

      <div class="col-md-10">
        <?php echo Form::text('judul', null, ['class'=>'form-control']); ?>

        <?php echo $errors->has('judul')?$errors->first('judul'):''; ?>

      </div>
    </div>
    <br>
    <br>
    <div class="form-gorup">
      <?php echo Form::label('kategori', 'Kategori', ['class'=>'control-label col-md-2']); ?>

      <div class="col-md-10">
        <?php echo Form::text('kategori', null, ['class'=>'form-control']); ?>

        <?php echo $errors->has('kategori')?$errors->first('kategori'):''; ?>

      </div>
    </div>
    <br>
    <br>
    <div class="form-gorup" style="margin-bottom: 14px;">
      <?php echo Form::label('berita', 'Berita', ['class'=>'control-label col-md-2']); ?>

      <div class="col-md-10">
        <?php echo Form::textArea('berita', null, ['class'=>'form-control']); ?>

        <?php echo $errors->has('berita')?$errors->first('berita'):''; ?>

      </div>
    </div>
    
    <br>
    <br>


    <br>
    <br>

    <div class="form-gorup">
      <div class="col-md-offset-2 col-md-10">
        <input type="submit" value="save" class="btn btn-primary" style="margin-top: 14px;">
      </div>
    </div>
  <?php echo Form::close(); ?>

      </div>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>

            <!-- /.box-footer -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>