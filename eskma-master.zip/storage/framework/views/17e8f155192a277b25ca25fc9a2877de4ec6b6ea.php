<h2><?php echo e($submit); ?> Kuesioner</h2>
<div class="form-group">
	<select name="unsur" id="unsur" class="form-control">
		<?php $__currentLoopData = $unsur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			<option value="<?php echo e($u->id); ?>"><?php echo e($u->unsur); ?></option>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	</select>
</div>
<div class="form-group">
	<?php echo Form::number('jum',null,['class'=>'form-control','placeholder'=>'Jumlah Kuesioner','id'=>'jum']); ?>

</div>
<div class="form-group">
	<?php echo Form::button('Tambah',['class'=>'btn','id'=>'btnJum']); ?>

</div>
<div id="hasil"></div>
<div class="form-group">
	<?php echo Form::submit('Simpan',['class'=>'btn btn-primary']); ?>

</div>