<?php $__env->startSection('content'); ?>
<?php echo Form::model($user,['route' => ['kabupaten.update',$user->id],'method'=>'PUT']); ?>

<?php echo e(Form::token()); ?>

    <!-- // -->
<h2>Profil</h2>
<div class="form-group">
	<?php echo Form::label('nama', 'Nama'); ?>

	<?php echo Form::text('nama', $k, ['class'=>'form-control','id'=>'nama']); ?>

</div>
<div class="form-group">
	<?php echo Form::label('username', 'Username'); ?>

	<?php echo Form::text('username', $user->name, ['class'=>'form-control','id'=>'username']); ?>

</div>
<div class="form-group">
	<?php echo Form::label('email', 'Email'); ?>

	<?php echo Form::email('email', $user->email, ['class'=>'form-control','id'=>'email']); ?>

</div>
<div class="form-group">
	<?php echo Form::label('password', 'Password'); ?>

	<!-- Form::input('password', 'name', 'value') -->
	<?php echo Form::password('password',['class'=>'form-control','id'=>'password']); ?>

</div>
<div class="form-group">
	<!-- <?php echo Form::submit('Simpan',['class'=>'btn btn-primary']); ?> -->
	<button type="button" class="btn btn-primary">Simpan</button>
</div>
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>