<?php $__env->startSection('content'); ?>
<?php echo Form::model($kuesioner,['route' => ['kuesionerv2.update',$kuesioner->id],'method'=>'PUT']); ?>

<?php echo e(Form::token()); ?>

    //
    <h4><?php echo e($kuesioner->unsur->unsur); ?></h4>
    <div class="form-group">
	    <?php echo Form::label('pertanyaan','Pertanyaan'); ?>

	    <?php echo Form::text('pertanyaan',$kuesioner->pertanyaan,['class'=>'form-control']); ?>

	</div>
	<?php echo Form::submit('Simpan',['class'=>'btn btn-primary']); ?> 
	<a href="<?php echo e(route('kuesioner.index',['id'=>$kuesioner->upp->id])); ?>" class="btn btn-default">Kembali</a>
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master.main2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>