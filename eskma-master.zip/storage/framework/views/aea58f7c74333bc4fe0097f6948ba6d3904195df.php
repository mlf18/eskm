<?php $__env->startSection('content'); ?>    
    <h2>UPP</h2>
    <a href="<?php echo e(route('upp.tambah')); ?>" class="btn btn-primary" style="margin-bottom: 20px;">Tambah</a>
    <div class="table-responsive">
        <table class="table table-striped table-sm">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users->upp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $upp): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($upp->nama); ?></td>
                    <td>
                        <a href="<?php echo e(route('kuesionerv2.index',['id'=>$upp->id])); ?>" class="btn btn-primary" data-toggle="tooltip" title="Lihat Kuesioner">Lihat</a>
                        <a href="<?php echo e(route('upp.edit',['id'=>$upp->user_id])); ?>" class="btn btn-light" data-toggle="tooltip" title="Edit Upp">Edit</a>
                        <a href="#" class="btn btn-danger" data-toggle="tooltip" title="Hapus Upp">Hapus</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>