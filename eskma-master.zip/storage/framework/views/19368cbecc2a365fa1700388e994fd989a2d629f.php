<?php $__env->startSection('content'); ?>
<?php if($kuesioner->count()>0): ?>
<h3>Kuesioner <?php echo e($kuesioner->first()->upp->nama); ?></h3>
<?php echo Form::open(['route' => 'jawab.store', 'files' => true]); ?>

<h2>Data Responden</h2>
<div class="form-group">
	<?php echo Form::label('nik', 'NIK'); ?>

	<?php echo Form::text('nik', null, ['class'=>'form-control','id'=>'nik']); ?>

</div>
<div class="form-group">
	<?php echo Form::label('nama', 'NAMA'); ?>

	<?php echo Form::text('nama', null, ['class'=>'form-control','id'=>'nama']); ?>

</div>
<div class="form-group">
	<?php echo Form::label('kabupaten', 'Kabupaten'); ?>

	<?php echo Form::select('kabupaten', $kabupaten, null,['class'=>'form-control']);; ?>

</div>
<div class="form-group">
	<?php echo Form::label('umur', 'Umur'); ?>

	<?php echo Form::number('umur', null, ['class'=>'form-control','id'=>'umur']); ?>

</div>
<div class="form-group">
	<?php echo Form::label('jk', 'Jenis Kelamin'); ?><br/>
		<?php echo Form::radio('jk','laki-laki',true,['class'=>'minimal']); ?> Laki Laki
		<?php echo Form::radio('jk','perempuan',false,['class'=>'minimal']); ?> Perempuan
</div>
<div class="form-group">
	<?php echo Form::label('pendidikan', 'Pendidikan'); ?>

	<?php echo Form::select('pendidikan', ['SD' => 'SD', 'SMP' => 'Smp'], 'SD',['class'=>'form-control']);; ?>

</div>
<div class="form-group">
	<?php echo Form::label('pekerjaan', 'Pekerjaan'); ?>

	<?php echo Form::select('pekerjaan', ['swasta' => 'Swasta', 'PNS' => 'PNS'], 'S',['class'=>'form-control']);; ?>

</div>
	<?php $__currentLoopData = $kuesioner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<div class="form-group">
			<input type="hidden" name="kues[<?php echo e($i); ?>][kuesioner_id]" value="<?php echo e($k->id); ?>">
			<?php if($k->where('unsur_id','=',$k->unsur_id)->where('upp_id','=',$k->upp_id)->count() < 2): ?>
			<h4><?php echo e($no.'. '.$k->unsur->unsur); ?></h4>
			<label for="kues[]"><?php echo e($k->pertanyaan); ?></label>
			<?php $no++;?>
			<?php else: ?>
			<?php if($unsur != $k->unsur_id): ?>
			<h4><?php echo e($no.'. '.$k->unsur->unsur); ?></h4>
			<?php $unsur=$k->unsur_id;?>
			<?php $no++;?>
			<?php endif; ?>
			<label for="kues[]"><?php echo e($k->pertanyaan); ?></label>
			<?php endif; ?>
			<div class="row">
				<div class="col-md-6">
					<div class="col-md-6">
						<h4>Penilaian Kinerja</h4>
						<?php echo $k->unsur->kinerja($k->unsur->id,'form',$i);?>		
					</div>
					<div class="col-md-6">
						<h4>Tingkat Kepentingan</h4>
						<p><input type="radio" name="kues[<?php echo e($i); ?>][kepentingan]" value="1" checked /> a. Tidak Penting</p>
						<p><input type="radio" name="kues[<?php echo e($i); ?>][kepentingan]" value="2" /> b.Kurang Penting</p>
						<p><input type="radio" name="kues[<?php echo e($i); ?>][kepentingan]" value="3" /> c. Penting</p>
						<p><input type="radio" name="kues[<?php echo e($i); ?>][kepentingan]" value="4" /> d. Sangat Penting</p>
					</div>
				</div>
				<div class="clearfix"></div>
			</div>
			<!-- <input type="text" name="kues[]" class="form-control"> -->
		</div>
		<?php $i++;?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	<?php if($preview != true): ?>
	<div class="form-group">
		<?php echo Form::submit('Simpan',['class'=>'btn btn-primary']); ?>

	</div>
	<?php endif; ?>

<?php echo Form::close(); ?>

<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>