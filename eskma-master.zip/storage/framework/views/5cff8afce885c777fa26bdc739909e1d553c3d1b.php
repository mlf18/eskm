<h2><?php echo e($submit); ?> OPD</h2>
<div class="form-group">
	<?php echo Form::label('nama', 'Nama'); ?>

	<?php echo Form::text('nama', $opd, ['class'=>'form-control','id'=>'nama']); ?>

</div>
<div class="form-group">
	<?php echo Form::label('username', 'Username'); ?>

	<?php echo Form::text('username', $user->name, ['class'=>'form-control','id'=>'username']); ?>

</div>
<div class="form-group">
	<?php echo Form::label('email', 'Email'); ?>

	<?php echo Form::email('email', $user->email, ['class'=>'form-control','id'=>'email']); ?>

</div>
<div class="form-group">
	<?php echo Form::label('password', 'Password'); ?>

	<!-- Form::input('password', 'name', 'value') -->
	<?php echo Form::password('password',['class'=>'form-control','id'=>'password']); ?>

</div>
<div class="form-group">
	<?php echo Form::submit('Simpan',['class'=>'btn btn-primary']); ?>

</div>