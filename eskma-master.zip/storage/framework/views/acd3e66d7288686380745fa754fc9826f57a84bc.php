<?php $__env->startSection('content'); ?>    
    <h2>OPD</h2>
    <a href="<?php echo e(route('opd.tambah')); ?>" class="btn btn-primary" style="margin-bottom: 20px;">Tambah</a>
    <div class="table-responsive">
        <table class="table table-striped table-sm">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($u->nama); ?></td>
                    <td><a href="<?php echo e(route('opd.edit',['id'=>$u->user->id])); ?>" class="btn btn-primary">Edit</a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>