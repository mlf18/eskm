<?php $__env->startSection('content'); ?>    
    <h2>Kuesioner</h2>
    <?php if($kuesioner->count() < 1): ?>
    <a href="<?php echo e(url('kuesioner/tambah/'.$id)); ?>" class="btn btn-primary" style="margin-bottom: 20px;">Tambah</a>
    <?php endif; ?>
    <a href="<?php echo e(url('kuesioner/preview/'.$id)); ?>" class="btn btn-success" style="margin-bottom: 20px;">Preview</a>
    <a href="<?php echo e(url('kuesioner/jawab/'.$id)); ?>" class="btn btn-info" style="margin-bottom: 20px;">Jawab</a>
    <a href="<?php echo e(route('upp.index')); ?>" class="btn btn-default" style="margin-bottom: 20px;">Kembali</a>
    <div class="table-responsive">
        <table class="table table-striped table-sm">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $kuesioner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($k->pertanyaan); ?></td>
                    <td>
                        <a href="<?php echo e(route('kuesioner.edit',['id'=>$k->id])); ?>" class="btn btn-primary" data-toggle="tooltip" title="Lihat Kuesioner">Edit</a>
                        <a href="" class="btn btn-danger" data-toggle="tooltip" title="Lihat Kuesioner">Hapus</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>