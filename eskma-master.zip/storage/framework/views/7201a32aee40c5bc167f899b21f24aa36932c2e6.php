<h2><?php echo e($submit); ?> Kuesioner</h2>
<?php $__currentLoopData = $unsur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<div class="form-group">
	<h4>Unsur <?php echo e($i.'. '.$u->unsur); ?><?php echo e($u->id==99?'(optional)':''); ?></h4>
	<label for = "pertanyaan[<?php echo e($i-1); ?>][pertanyaan]">Pertanyaan</label>
	<input type="text" name="pertanyaan[<?php echo e($i-1); ?>][pertanyaan][0]" class="form-control" value="<?php echo e($u->templatekues['pertanyaan']); ?>" />
	<input type="text" name="pertanyaan[<?php echo e($i-1); ?>][pertanyaan][1]" class="form-control" value="" placeholder="(optional)" />
	<button type="button" class="btn btn-light" style="margin-top: 10px;">Tambah</button>
	<input type="hidden" name="pertanyaan[<?php echo e($i-1); ?>][kategori]" value="text">
	<input type="hidden" name="pertanyaan[<?php echo e($i-1); ?>][unsur_id]" value="<?php echo e($u->id); ?>">
	<div class="row">
		<div class="col-md-6">
			<div class="col-md-6">
				<h4>Penilaian Kinerja</h4>
				<?php echo $u->kinerja($u->id,'','');?>		
			</div>
			<div class="col-md-6">
				<h4>Tingkat Kepentingan</h4>
				<p>a. Tidak Penting</p>
				<p>b.Kurang Penting</p>
				<p>c. Penting</p>
				<p>d. Sangat Penting</p>
			</div>
		</div>
	</div>
</div>
<?php $i++;?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
<div class="form-group">
	<?php echo Form::submit('Simpan',['class'=>'btn btn-primary']); ?>

</div>