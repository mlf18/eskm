<h2><?php echo e($submit); ?> UPP</h2>
<div class="form-group">
	<?php echo Form::label('username', 'User Name'); ?>

	<?php echo Form::text('username', $user->name, ['class'=>'form-control','id'=>'username']); ?>

	<?php echo Form::label('nama', 'Nama'); ?>

	<?php echo Form::text('nama', isset($user->upp->nama)?$user->upp->nama:'', ['class'=>'form-control','id'=>'nama']); ?>

	<?php echo Form::label('email', 'Email'); ?>

	<?php echo Form::text('email', $user->email, ['class'=>'form-control','id'=>'email']); ?>

	<?php echo Form::label('password', 'Password'); ?>

	<?php echo Form::password('password', ['class'=>'form-control','id'=>'password']); ?>

</div>
<div class="form-group">
	<?php echo Form::submit('Simpan',['class'=>'btn btn-primary']); ?>

</div>