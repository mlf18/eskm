<?php $__env->startSection('content'); ?>
<?php echo Form::model($kuesioner,['route' => ['kuesionerv2.store',$id],'method'=>'POST']); ?>

<?php echo e(Form::token()); ?>

    //
    <?php echo $__env->make('kuesioner._form',['submit'=>'Tambah'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>