<?php $__env->startSection('content'); ?>
<?php echo Form::model($user,['route' => 'opd.store','method'=>'POST']); ?>

<?php echo e(Form::token()); ?>

    //
    <?php echo $__env->make('super.opd._form',['submit'=>'Tambah'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master.main2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>